function results = run_comparison()
%RUN_COMPARISON Replay four PMSM simulations at 1,000 rpm and 1 N m.
% Extract the ZIP, select the extracted folder in MATLAB and run:
%   results = run_comparison()
% Requires MATLAB/Simulink R2026b, Simscape and Simscape Electrical.
%
% A1_NoDelay          Immediate gate update; reference for ideal timing.
% A2_Delayed          One-update gate delay, no delay compensation.
% A3_DelayCompensated Same delay; prediction includes the applied voltage.
% A3_FluxPlus20       Same as A3, with controller magnet flux set 20% high.
% All four retain the same anti-windup rule. The motor parameters stay fixed.
%
% Each .slx file can also be opened and run on its own.
models = ["A1_NoDelay"; "A2_Delayed"; "A3_DelayCompensated"; "A3_FluxPlus20"];
folder = fileparts(mfilename('fullpath'));
torqueRMSE = zeros(size(models));
phaseRMS = zeros(size(models));
for k = 1:numel(models)
    fprintf('Running %s (%d of %d)\n', models(k), k, numel(models));
    [torqueRMSE(k), phaseRMS(k)] = measureCase(models(k), folder);
end
results = table(models, torqueRMSE, phaseRMS, 'VariableNames', ...
    {'Model', 'TorqueTrackingRMSE_Nm', 'PhaseCurrentRMS_A'});
end

function [torqueRMSE, phaseRMS] = measureCase(name, folder)
file = fullfile(folder, name + ".slx");
if bdIsLoaded(name)
    assert(strcmp(get_param(name, 'FileName'), file) && ...
        strcmp(get_param(name, 'Dirty'), 'off'), ...
        'Save and close the open copy of %s before running the comparison.', name);
else
    load_system(file);
    cleanup = onCleanup(@() close_system(name, 0)); %#ok<NASGU>
end
out = sim(Simulink.SimulationInput(name));
torque = out.logsout.getElement('torque_actual_load_ref').Values;
% The report uses the full 0.65 to 0.90 s window, including both endpoints.
ticks = round(torque.Time * 1e6);
window = ticks >= 650000 & ticks <= 900000;
assert(nnz(window) == 250001, 'The steady-state time window is incomplete.');
errorNm = torque.Data(window, 1) - torque.Data(window, 3);
torqueRMSE = sqrt(mean(errorNm.^2));  % Shaft torque minus requested torque.
channels = ["plant_ia", "plant_ib", "plant_ic"];
phaseMeanSquare = zeros(1, 3);
for phase = 1:3
    current = out.logsout.getElement(char(channels(phase))).Values;
    assert(isequal(current.Time, torque.Time), 'The logged time grids differ.');
    phaseMeanSquare(phase) = mean(current.Data(window).^2);
end
phaseRMS = sqrt(mean(phaseMeanSquare));  % RMS across time and all three phases.
end
