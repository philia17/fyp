PMSM predictive torque control | Four Simulink models

REPLAY THE COMPARISON
1. Extract the ZIP. In MATLAB, set Current Folder to the folder that
   contains run_comparison.m and the four .slx files.
2. In the Command Window, enter:  results = run_comparison()
   MATLAB runs all four models and displays one row per model.
3. To inspect the compensated controller, enter:
      open_system('A3_DelayCompensated')
   Double-click PTC controller. Its speed_PI_controller subsystem
   contains the speed loop and its anti-windup rule.

Software used: MATLAB and Simulink R2026b with Simscape and
Simscape Electrical. Each model stores its simulation inputs in its
own model workspace. No separate initialisation script or data file
is needed.

WHAT TO COMPARE
All four simulate 0.90 s with a 1,000 rpm speed command, a 1 N m load
and the same motor. The controller updates every 50 microseconds.

Model                 Change                               E_T     I_RMS
A1_NoDelay            Immediate gate command               0.129   1.274
A2_Delayed            Gate command delayed one update      0.351   1.405
A3_DelayCompensated   Controller accounts for that delay   0.128   1.275
A3_FluxPlus20         A3 assumes 20% more magnet flux      0.173   2.452

E_T (N m) is the root-mean-square difference between shaft torque
and requested torque. I_RMS (A) is the root-mean-square current
across all three phases. Both use 0.65 to 0.90 s, including both
endpoints. The table gives the report data rounded to three decimals.

HOW TO READ THE RESULTS
Compare A2 with A3 to isolate delay compensation. Compare the two A3
rows to isolate the controller's flux assumption. The latter changes
the value used by the estimator and predictor together. Motor flux
and the controller's stator-flux target stay fixed.

Source: FYP Simulation Report, Appendix B, "Reproducing the results".
The three nominal rows come from baseline_observability.csv. The
flux-mismatch row is AWR_A3_nominal_psi_120 in parameter_mismatch_audit.csv.
This package replays those four desktop simulations at one operating point.
